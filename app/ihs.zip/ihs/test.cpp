#include "main.h"

int main() {
	App myApp;
	myApp.run();
	return 0;
}
